# BodyControl — standalone interactive widget 1.3.0

Это самостоятельная Android-игрушка, стилизованная под интерфейс мода BodyControl из Minecraft. **Подключения к Minecraft, серверу, Health Connect, интернету или любым внешним данным нет.** Все показатели — локальная симуляция.

## Что внутри

- Пиксельный виджет с сердцем, водой, едой и энергией.
- Три кнопки прямо на виджете: пить, есть, отдыхать.
- Нажатие на основную часть виджета открывает приложение.
- Полноэкранный интерфейс в стиле скриншотов BodyControl.
- Вкладки **Системы / Сейчас / Каскады / Журнал**.
- 7 интерактивных систем: сердце, кровь, мозг, дыхание, желудок, мышцы, энергия.
- Детальные страницы систем с показателями, состоянием и действиями.
- Каскады автоматически зависят от текущего состояния.
- Журнал сохраняет действия пользователя локально.
- Уведомления можно включать и выключать.
- Значения постепенно расходуются со временем.
- Всё работает без разрешений на интернет и без привязки к игре.

## Важно

Проект намеренно сделан без реального медицинского смысла. Показатели являются игровой симуляцией и не предназначены для оценки здоровья человека.

# Как загрузить проект в GitHub и получить APK

Самый простой способ — **не загружать ZIP как один файл**. Сначала распакуй ZIP, затем загрузи содержимое проекта в корень GitHub-репозитория.

### Вариант 1 — через сайт GitHub

1. Создай новый репозиторий на GitHub, например `BodyControlWidget`.
2. Скачай этот ZIP и распакуй его.
3. В распакованной папке должны сразу находиться:
   - `app/`
   - `.github/`
   - `build.gradle.kts`
   - `settings.gradle.kts`
   - `gradle.properties`
   - `README.md`
4. На GitHub нажми **Add file → Upload files**.
5. Перетащи **все эти файлы и папки** в окно загрузки.
6. Нажми **Commit changes**.
7. Открой вкладку **Actions**.
8. Запусти workflow **Build BodyControl APK**. Если push уже был, сборка запустится автоматически.
9. После окончания сборки открой зелёный успешный запуск workflow.
10. Внизу страницы в разделе **Artifacts** скачай `BodyControl-1.3.0-debug`.
11. Распакуй artifact и установи APK на телефон.

### Вариант 2 — через Git

В терминале из распакованной папки проекта:

```bash
git init
git add .
git commit -m "BodyControl widget 1.3.0"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

После push GitHub Actions сам соберёт APK.

## Сборка локально

Проект использует Gradle 8.9 и Java 17. Gradle Wrapper намеренно не нужен: GitHub Actions сам устанавливает Gradle. В Android Studio проект открывается из папки, где находятся `settings.gradle.kts` и `app/`.

## Структура

```text
BodyControlWidget/
├── app/
│   └── src/main/
│       ├── java/com/example/bodywidget/
│       │   ├── BodyControlView.kt
│       │   ├── BodyState.kt
│       │   ├── BodyWidget.kt
│       │   ├── MainActivity.kt
│       │   └── MinecraftRenderer.kt
│       └── res/
├── .github/workflows/build.yml
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```
