package com.example.bodywidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.sin

/** Local-only simulation. Nothing here connects to Minecraft or the network. */
data class BodyState(
    val water: Float,
    val food: Float,
    val energy: Float,
    val updatedAt: Long,
) {
    val pulse: Int
        get() {
            val stress = (100 - water) * 0.20f + (100 - food) * 0.10f + (100 - energy) * 0.25f
            val jitter = (sin(updatedAt / 60_000.0) * 2).toInt()
            return ((55 + stress).toInt() + jitter).coerceIn(42, 135)
        }

    fun advance(now: Long): BodyState {
        val hours = ((now - updatedAt) / 3_600_000f).coerceAtLeast(0f)
        return copy(
            water = (water - WATER_PER_HOUR * hours).coerceIn(0f, 100f),
            food = (food - FOOD_PER_HOUR * hours).coerceIn(0f, 100f),
            energy = (energy - ENERGY_PER_HOUR * hours).coerceIn(0f, 100f),
            updatedAt = now,
        )
    }

    companion object {
        const val WATER_PER_HOUR = 8f
        const val FOOD_PER_HOUR = 5f
        const val ENERGY_PER_HOUR = 4f
        const val DRINK = 25f
        const val EAT = 30f
        const val REST = 30f
    }
}

data class BodyEvent(val message: String, val kind: String = "past", val time: Long = System.currentTimeMillis())

object BodyStore {
    private const val PREFS = "body_state"
    private const val EVENTS = "events"

    fun current(ctx: Context): BodyState {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val state = BodyState(
            water = p.getFloat("water", 74f),
            food = p.getFloat("food", 34f),
            energy = p.getFloat("energy", 100f),
            updatedAt = p.getLong("t", now),
        ).advance(now)
        save(ctx, state)
        return state
    }

    fun update(ctx: Context, change: (BodyState) -> BodyState, event: String? = null) {
        save(ctx, change(current(ctx)))
        if (event != null) addEvent(ctx, event)
    }

    fun events(ctx: Context): List<BodyEvent> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(EVENTS, null) ?: return defaultEvents()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(BodyEvent(o.optString("message"), o.optString("kind", "past"), o.optLong("time")))
                }
            }.ifEmpty { defaultEvents() }
        } catch (_: Exception) { defaultEvents() }
    }

    fun addEvent(ctx: Context, message: String, kind: String = "past") {
        val current = events(ctx).toMutableList()
        current.add(0, BodyEvent(message, kind))
        val arr = JSONArray()
        current.take(24).forEach {
            arr.put(JSONObject().apply {
                put("message", it.message)
                put("kind", it.kind)
                put("time", it.time)
            })
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(EVENTS, arr.toString()).apply()
    }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    private fun save(ctx: Context, s: BodyState) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("water", s.water)
            .putFloat("food", s.food)
            .putFloat("energy", s.energy)
            .putLong("t", s.updatedAt)
            .apply()
    }

    private fun defaultEvents() = listOf(
        BodyEvent("Сердце снова бьётся."),
        BodyEvent("Сердце замирает."),
        BodyEvent("Получено достижение: «Что такое кардиостимулятор?»", "achievement"),
        BodyEvent("Дыхание выровнялось."),
        BodyEvent("Голова кружится от избытка воздуха.", "warning"),
        BodyEvent("Пульс поднялся до нормы."),
        BodyEvent("Сердце бьётся слишком редко.", "warning"),
        BodyEvent("Дыхание выровнялось."),
        BodyEvent("Получено достижение: «Первый перелом»", "achievement"),
        BodyEvent("Кровь течёт медленнее.", "warning"),
        BodyEvent("Энергия восстановилась."),
    )
}
