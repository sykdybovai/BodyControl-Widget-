package com.example.bodywidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import kotlin.math.min
import kotlin.math.roundToInt

class BodyWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val s = BodyStore.current(context)
        provideContent { Content(context, s) }
    }
}

class BodyWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = BodyWidget()
}

@Composable
private fun Content(context: Context, s: BodyState) {
    val size = LocalSize.current
    val w = MinecraftRenderer.W
    val aspect = if (size.width.value > 0f) size.height.value / size.width.value else 0.70f
    val h = MinecraftRenderer.heightFor(aspect)
    val k = min(size.width.value / w, size.height.value / h)
    val scale = (k * context.resources.displayMetrics.density).roundToInt().coerceIn(1, 6)
    val bmp = MinecraftRenderer.render(s, h, scale)
    val topDp = (MinecraftRenderer.buttonTop(h) * k).dp
    val btnDp = (MinecraftRenderer.BTN_H * k).dp
    val sideDp = (MinecraftRenderer.BTN_MARGIN * k).dp

    Box(modifier = GlanceModifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(modifier = GlanceModifier.size((w * k).dp, (h * k).dp)) {
            Image(
                provider = ImageProvider(bmp),
                contentDescription = "BodyControl",
                modifier = GlanceModifier.fillMaxSize().clickable(actionStartActivity<MainActivity>()),
                contentScale = ContentScale.FillBounds,
            )
            Column(modifier = GlanceModifier.fillMaxSize()) {
                Spacer(modifier = GlanceModifier.height(topDp))
                Row(modifier = GlanceModifier.fillMaxWidth().height(btnDp).padding(horizontal = sideDp)) {
                    Box(modifier = GlanceModifier.defaultWeight().fillMaxHeight().clickable(actionRunCallback<DrinkAction>())) {}
                    Box(modifier = GlanceModifier.defaultWeight().fillMaxHeight().clickable(actionRunCallback<EatAction>())) {}
                    Box(modifier = GlanceModifier.defaultWeight().fillMaxHeight().clickable(actionRunCallback<RestAction>())) {}
                }
            }
        }
    }
}

class DrinkAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        BodyStore.update(context, { it.copy(water = (it.water + BodyState.DRINK).coerceAtMost(100f)) }, "Выпита вода. Жажда отступила.")
        BodyWidget().updateAll(context)
    }
}

class EatAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        BodyStore.update(context, { it.copy(food = (it.food + BodyState.EAT).coerceAtMost(100f)) }, "Перекус завершён. Желудок доволен.")
        BodyWidget().updateAll(context)
    }
}

class RestAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        BodyStore.update(context, { it.copy(energy = (it.energy + BodyState.REST).coerceAtMost(100f)) }, "Отдых завершён. Энергия восстановилась.")
        BodyWidget().updateAll(context)
    }
}
