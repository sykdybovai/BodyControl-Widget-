package com.example.bodywidget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Standalone BodyControl-inspired UI. It is intentionally a toy/simulator. */
class BodyControlView(context: Context) : View(context) {
    private enum class Tab { SYSTEMS, NOW, CASCADES, JOURNAL }
    private enum class SystemId { HEART, BLOOD, BRAIN, BREATH, STOMACH, MUSCLES, ENERGY }

    private var tab = Tab.JOURNAL
    private var selected: SystemId? = null
    private var notifications = true
    private var scroll = 0f
    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var pulsePhase = 0f

    private val bg = Color.rgb(1, 5, 8)
    private val panel = Color.rgb(6, 11, 17)
    private val panel2 = Color.rgb(10, 17, 27)
    private val panel3 = Color.rgb(12, 22, 34)
    private val line = Color.rgb(63, 77, 91)
    private val cyan = Color.rgb(39, 187, 235)
    private val green = Color.rgb(73, 222, 91)
    private val yellow = Color.rgb(244, 216, 48)
    private val red = Color.rgb(224, 48, 56)
    private val white = Color.rgb(231, 234, 239)
    private val muted = Color.rgb(126, 136, 148)
    private val blue = Color.rgb(73, 142, 230)
    private val orange = Color.rgb(244, 151, 41)
    private val purple = Color.rgb(176, 93, 229)

    private val p = Paint().apply {
        isAntiAlias = false
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        style = Paint.Style.FILL
    }

    init {
        isFocusable = true
        setBackgroundColor(bg)
        notifications = context.getSharedPreferences("body_ui", Context.MODE_PRIVATE)
            .getBoolean("notifications", true)
        post(object : Runnable {
            override fun run() {
                pulsePhase += .20f
                invalidate()
                postDelayed(this, 70L)
            }
        })
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        drawGrid(c, w, h)
        val margin = max(18f, w * .035f)
        val top = max(34f, h * .055f)
        val right = w - margin
        val bottom = h - max(18f, h * .035f)
        drawFrame(c, margin, top, right, bottom)
        drawHeader(c, margin + 10f, top + 10f, right - 10f, top + 72f)
        val contentTop = top + 88f
        val contentBottom = bottom - 12f
        if (selected != null) drawSystemDetail(c, margin + 14f, contentTop, right - 14f, contentBottom, selected!!)
        else drawContent(c, margin + 14f, contentTop, right - 14f, contentBottom)
    }

    private fun drawGrid(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.rgb(7, 19, 24)
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, p); x += 16f }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, p); y += 16f }
        p.style = Paint.Style.FILL; p.color = Color.rgb(36, 112, 63)
        c.drawRect(22f, 30f, 58f, 32f, p); c.drawRect(22f, 30f, 24f, 62f, p)
        c.drawRect(w - 58f, 30f, w - 22f, 32f, p); c.drawRect(w - 24f, 30f, w - 22f, 62f, p)
        c.drawRect(22f, h - 30f, 58f, h - 32f, p); c.drawRect(22f, h - 62f, 24f, h - 30f, p)
        c.drawRect(w - 58f, h - 30f, w - 22f, h - 32f, p); c.drawRect(w - 24f, h - 62f, w - 22f, h - 30f, p)
    }

    private fun drawFrame(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        p.style = Paint.Style.FILL; p.color = panel; c.drawRect(l, t, r, b, p)
        p.color = Color.rgb(28, 53, 68)
        c.drawRect(l, t, r, t + 3f, p); c.drawRect(l, b - 3f, r, b, p)
        c.drawRect(l, t, l + 3f, b, p); c.drawRect(r - 3f, t, r, b, p)
        p.color = bg
        c.drawRect(l, t, l + 9f, t + 9f, p); c.drawRect(r - 9f, t, r, t + 9f, p)
        c.drawRect(l, b - 9f, l + 9f, b, p); c.drawRect(r - 9f, b - 9f, r, b, p)
    }

    private fun drawHeader(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        val labels = listOf("Системы", "Сейчас", "Каскады", "Журнал")
        val gap = 6f; val tabW = (r - l - gap * 3) / 4f
        labels.forEachIndexed { i, label ->
            val x = l + i * (tabW + gap)
            button(c, x, t, x + tabW, b, label, i == tab.ordinal, if (i == 3) yellow else cyan)
        }
        val label = if (notifications) "Уведомления: вкл" else "Уведомления: выкл"
        val tw = measure(label, 15f) + 24f
        button(c, r - tw, max(1f, t - 39f), r, t - 7f, label, false, if (notifications) cyan else red)
    }

    private fun button(c: Canvas, l: Float, t: Float, r: Float, b: Float, label: String, selected: Boolean, accent: Int) {
        p.style = Paint.Style.FILL; p.color = if (selected) Color.rgb(12, 42, 55) else Color.rgb(17, 22, 29)
        c.drawRect(l, t, r, b, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = if (selected) accent else Color.rgb(75, 89, 103)
        c.drawRect(l + 1, t + 1, r - 1, b - 1, p)
        p.style = Paint.Style.FILL
        text(c, (l + r) / 2f, (t + b) / 2f + 6f, label, 15f, if (selected) white else Color.rgb(185, 191, 199), true)
    }

    private fun drawContent(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        when (tab) {
            Tab.SYSTEMS -> drawSystems(c, l, t, r, b)
            Tab.NOW -> drawNow(c, l, t, r, b)
            Tab.CASCADES -> drawCascades(c, l, t, r, b)
            Tab.JOURNAL -> drawJournal(c, l, t, r, b)
        }
    }

    private fun drawSystems(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        title(c, (l + r) / 2, t + 27, "СИСТЕМЫ")
        val rows = listOf(
            Triple(SystemId.HEART, "Сердце", "Пульс ${pulse()} BPM", red),
            Triple(SystemId.BLOOD, "Кровь", "Кислород ${oxygen()}%", red),
            Triple(SystemId.BRAIN, "Мозг", "Нагрузка ${brainLoad()}%", blue),
            Triple(SystemId.BREATH, "Дыхание", "Ритм ${breath()} / мин", cyan),
            Triple(SystemId.STOMACH, "Желудок", "Сытость ${food()}%", orange),
            Triple(SystemId.MUSCLES, "Мышцы", "Тонус ${muscle()}%", purple),
            Triple(SystemId.ENERGY, "Энергия", "Ресурс ${energy()}%", yellow),
        )
        val start = t + 48f; val gap = 7f
        val rh = min(67f, (b - start - (rows.size - 1) * gap) / rows.size)
        rows.forEachIndexed { i, row ->
            val y = start + i * (rh + gap)
            systemRow(c, l, y, r, y + rh, row.first, row.second, row.third, row.fourth)
        }
    }

    private fun systemRow(c: Canvas, l: Float, t: Float, r: Float, b: Float, id: SystemId, name: String, value: String, color: Int) {
        p.color = panel2; c.drawRect(l, t, r, b, p); p.color = color; c.drawRect(l, t, l + 5f, b, p)
        drawSystemIcon(c, l + 18f, t + 17f, id, color)
        text(c, l + 55f, t + 27f, name, 17f, white, false)
        text(c, l + 55f, t + 49f, value, 12f, muted, false)
        text(c, r - 24f, t + 36f, "›", 27f, color, true)
        if (id == SystemId.HEART && System.currentTimeMillis() % 900 < 450) {
            p.color = Color.argb(28, Color.red(red), Color.green(red), Color.blue(red)); c.drawRect(l + 5f, t, r, b, p)
        }
    }

    private fun drawNow(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        title(c, (l + r) / 2, t + 27, "СЕЙЧАС ВЛИЯЮТ")
        val s = state()
        val items = mutableListOf<Pair<String, String>>()
        if (s.water < 45) items += "Жажда +30" to "Сердце — пульс повышен."
        if (s.water < 60) items += "Жажда +30" to "Кровь — кислород переносится хуже."
        if (s.water < 55) items += "Жажда +25" to "Мышцы — руки хуже слушаются."
        if (s.water < 65) items += "Жажда +30" to "Энергия — силы уходят быстрее."
        if (s.food < 45) items += "Сытость -25" to "Энергия — восстановление замедлено."
        if (s.energy < 40) items += "Энергия -30" to "Дыхание — ритм становится нестабильным."
        if (items.isEmpty()) items += "Организм +0" to "Серьёзных влияний не обнаружено. Пока что."
        var y = t + 48f - scroll
        items.forEachIndexed { i, item ->
            if (y + 65 > t && y < b) {
                p.color = panel2; c.drawRect(l, y, r, y + 58, p)
                p.color = if (i < 4) green else Color.rgb(58, 79, 90); c.drawRect(l, y, l + 4, y + 58, p)
                text(c, l + 16, y + 21, item.first, 13f, if (i == 1) yellow else cyan, false)
                textBlock(c, l + 16, y + 42, item.second, 11f, white, r - 12)
            }
            y += 65
        }
        miniBar(c, l, b - 34, r, "Сердце", pulse() / 120f, red, "${pulse()} BPM")
    }

    private fun drawCascades(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        title(c, (l + r) / 2, t + 27, "СЕЙЧАС ВЛИЯЮТ")
        text(c, l + 8, t + 52, "ЦЕПОЧКИ ВЛИЯНИЙ", 12f, muted, false)
        val s = state()
        val list = listOf(
            Triple("Жажда +30", "Сердце", s.water < 45),
            Triple("Жажда +30", "Кровь", s.water < 60),
            Triple("Жажда +25", "Мышцы", s.water < 55),
            Triple("Жажда +30", "Энергия", s.water < 65),
            Triple("Сытость -25", "Энергия", s.food < 45),
            Triple("Энергия -30", "Дыхание", s.energy < 40),
        )
        var y = t + 67f - scroll
        list.forEach { item ->
            if (y + 72 > t && y < b) {
                p.color = Color.rgb(6, 12, 21); c.drawRect(l + 10, y, r - 10, y + 62, p)
                p.color = if (item.third) green else Color.rgb(48, 64, 76); c.drawRect(l + 10, y, l + 15, y + 62, p)
                text(c, l + 28, y + 23, item.first, 14f, if (item.third) cyan else muted, false)
                text(c, l + 28, y + 47, "→  ${item.second}", 15f, if (item.third) white else muted, false)
                text(c, r - 30, y + 36, if (item.third) "●" else "○", 13f, if (item.third) green else muted, true)
            }
            y += 72
        }
    }

    private fun drawJournal(c: Canvas, l: Float, t: Float, r: Float, b: Float) {
        title(c, (l + r) / 2, t + 27, "ЧТО ПРОИСХОДИЛО")
        val events = BodyStore.events(context)
        val rh = 61f; var y = t + 49f - scroll
        events.forEachIndexed { i, e ->
            if (y + 55 > t && y < b) {
                p.color = Color.rgb(13, 18, 26); c.drawRect(l, y, r, y + 55, p)
                val accent = when (e.kind) { "achievement" -> yellow; "warning" -> red; else -> Color.rgb(61, 68, 79) }
                p.color = accent; c.drawRect(l, y, l + 5, y + 55, p)
                textBlock(c, l + 17, y + 23, e.message, 13f, white, r - 112)
                val label = if (e.kind == "achievement") "Взято" else "Прошло"
                text(c, r - 75, y + 23, label, 12f, accent, true)
                text(c, r - 22, y + 25, "?", 14f, muted, true)
            }
            y += rh
        }
    }

    private fun drawSystemDetail(c: Canvas, l: Float, t: Float, r: Float, b: Float, id: SystemId) {
        val name = systemName(id); val color = systemColor(id); val center = (l + r) / 2
        button(c, l, t, r, t + 40, "‹  $name", true, color)
        drawSystemIcon(c, center - 22f, t + 62f, id, color, 44f)
        text(c, center, t + 137f, systemStatus(id), 15f, color, true)
        text(c, center, t + 184f, systemValue(id), 34f, white, true)
        text(c, center, t + 207f, systemUnit(id), 12f, muted, true)
        miniBar(c, l, t + 228f, r, name, systemPercent(id), color, systemPercent(id).toInt().toString() + "%")
        p.color = panel2; c.drawRect(l, t + 268f, r, b, p)
        text(c, l + 18, t + 296, "СОСТОЯНИЕ", 12f, muted, false)
        textBlock(c, l + 18, t + 322, systemDescription(id), 14f, white, r - 18)
        text(c, l + 18, t + 388, "ДЕЙСТВИЯ", 12f, muted, false)
        val acts = systemActions(id)
        val gap = 12f; val aw = (r - l - 36f - gap) / 2f
        acts.forEachIndexed { i, a -> button(c, l + 18 + i * (aw + gap), t + 405, l + 18 + i * (aw + gap) + aw, t + 451, a, false, color) }
        text(c, center, b - 15, "Нажмите ‹, чтобы вернуться", 11f, muted, true)
    }

    private fun systemName(id: SystemId) = when (id) { SystemId.HEART -> "Сердце"; SystemId.BLOOD -> "Кровь"; SystemId.BRAIN -> "Мозг"; SystemId.BREATH -> "Дыхание"; SystemId.STOMACH -> "Желудок"; SystemId.MUSCLES -> "Мышцы"; SystemId.ENERGY -> "Энергия" }
    private fun systemColor(id: SystemId) = when (id) { SystemId.HEART -> red; SystemId.BLOOD -> red; SystemId.BRAIN -> blue; SystemId.BREATH -> cyan; SystemId.STOMACH -> orange; SystemId.MUSCLES -> purple; SystemId.ENERGY -> yellow }
    private fun systemPercent(id: SystemId) = when (id) { SystemId.HEART -> (pulse() / 1.2f).coerceIn(0f, 100f); SystemId.BLOOD -> oxygen().toFloat(); SystemId.BRAIN -> brainLoad().toFloat(); SystemId.BREATH -> (breath() * 5f).coerceIn(0f, 100f); SystemId.STOMACH -> food().toFloat(); SystemId.MUSCLES -> muscle().toFloat(); SystemId.ENERGY -> energy().toFloat() }
    private fun systemValue(id: SystemId) = when (id) { SystemId.HEART -> pulse().toString(); SystemId.BLOOD -> oxygen().toString(); SystemId.BRAIN -> brainLoad().toString(); SystemId.BREATH -> breath().toString(); SystemId.STOMACH -> food().toString(); SystemId.MUSCLES -> muscle().toString(); SystemId.ENERGY -> energy().toString() }
    private fun systemUnit(id: SystemId) = when (id) { SystemId.HEART -> "BPM"; SystemId.BLOOD -> "% кислорода"; SystemId.BRAIN -> "% нагрузки"; SystemId.BREATH -> "вдохов / мин"; SystemId.STOMACH -> "% сытости"; SystemId.MUSCLES -> "% тонуса"; SystemId.ENERGY -> "% ресурса" }
    private fun systemStatus(id: SystemId) = when (id) { SystemId.HEART -> "РИТМ СТАБИЛЕН"; SystemId.BLOOD -> "КРОВООБРАЩЕНИЕ НОРМА"; SystemId.BRAIN -> "РАБОТАЕТ ШТАТНО"; SystemId.BREATH -> "ДЫХАНИЕ РОВНОЕ"; SystemId.STOMACH -> "ПЕРЕВАРИВАНИЕ"; SystemId.MUSCLES -> "ТОНУС ДОПУСТИМЫЙ"; SystemId.ENERGY -> "ЗАПАС ДОСТАТОЧНЫЙ" }
    private fun systemDescription(id: SystemId) = when (id) {
        SystemId.HEART -> "Сердце поддерживает циркуляцию крови. При низкой энергии и воде пульс постепенно повышается."
        SystemId.BLOOD -> "Кровь переносит кислород. Обезвоживание снижает эффективность переноса."
        SystemId.BRAIN -> "Мозг отслеживает состояние организма и реагирует на нехватку ресурсов."
        SystemId.BREATH -> "Дыхание автоматически подстраивается под нагрузку и уровень энергии."
        SystemId.STOMACH -> "Сытость уменьшается со временем и восстанавливается после еды."
        SystemId.MUSCLES -> "Мышцы получают энергию из общего ресурса организма. Недостаток воды ухудшает тонус."
        SystemId.ENERGY -> "Энергия расходуется постепенно и восстанавливается отдыхом."
    }
    private fun systemActions(id: SystemId) = when (id) {
        SystemId.STOMACH -> listOf("ПОЕСТЬ", "ОЧИСТИТЬ")
        SystemId.ENERGY -> listOf("ОТДОХНУТЬ", "РАЗРЯДИТЬ")
        SystemId.HEART -> listOf("УСПОКОИТЬ", "НАГРУЗИТЬ")
        else -> listOf("СТАБИЛИЗИР.", "ИМИТИРОВАТЬ")
    }

    private fun drawSystemIcon(c: Canvas, x: Float, y: Float, id: SystemId, color: Int, size: Float = 28f) {
        p.style = Paint.Style.FILL; p.color = Color.argb(45, Color.red(color), Color.green(color), Color.blue(color)); c.drawRect(x, y, x + size, y + size, p); p.color = color
        when (id) {
            SystemId.HEART -> { c.drawCircle(x + size*.36f, y + size*.42f, size*.19f, p); c.drawCircle(x + size*.64f, y + size*.42f, size*.19f, p); val q = Path(); q.moveTo(x + size*.18f, y + size*.45f); q.lineTo(x + size*.5f, y + size*.82f); q.lineTo(x + size*.82f, y + size*.45f); q.close(); c.drawPath(q, p) }
            SystemId.BLOOD -> { c.drawCircle(x + size*.5f, y + size*.48f, size*.25f, p); c.drawRect(x + size*.42f, y + size*.18f, x + size*.58f, y + size*.48f, p) }
            SystemId.BRAIN -> { c.drawCircle(x + size*.5f, y + size*.5f, size*.29f, p); p.color = panel; c.drawLine(x + size*.5f, y + size*.2f, x + size*.5f, y + size*.8f, p) }
            SystemId.BREATH -> { p.style = Paint.Style.STROKE; p.strokeWidth = 3f; val q = Path(); q.moveTo(x+2, y+size*.55f); q.cubicTo(x+size*.25f,y+size*.1f,x+size*.35f,y+size*.9f,x+size*.5f,y+size*.45f); q.cubicTo(x+size*.65f,y,x+size*.8f,y+size*.9f,x+size-2,y+size*.45f); c.drawPath(q,p); p.style = Paint.Style.FILL }
            SystemId.STOMACH -> c.drawOval(RectF(x+size*.25f,y+size*.15f,x+size*.72f,y+size*.82f), p)
            SystemId.MUSCLES -> { c.drawRect(x+size*.18f,y+size*.3f,x+size*.82f,y+size*.7f,p); c.drawRect(x+size*.05f,y+size*.36f,x+size*.28f,y+size*.62f,p); c.drawRect(x+size*.72f,y+size*.36f,x+size*.95f,y+size*.62f,p) }
            SystemId.ENERGY -> { val q = Path(); q.moveTo(x+size*.6f,y); q.lineTo(x+size*.25f,y+size*.52f); q.lineTo(x+size*.48f,y+size*.52f); q.lineTo(x+size*.38f,y+size); q.lineTo(x+size*.75f,y+size*.42f); q.lineTo(x+size*.53f,y+size*.42f); q.close(); c.drawPath(q,p) }
        }
    }

    private fun miniBar(c: Canvas, l: Float, y: Float, r: Float, name: String, value: Float, color: Int, label: String) {
        text(c, l + 4, y + 17, name, 12f, white, false)
        val x1 = l + 105; val x2 = r - 95
        p.color = Color.rgb(58, 66, 77); c.drawRect(x1, y + 7, x2, y + 18, p)
        p.color = color; c.drawRect(x1, y + 7, x1 + (x2-x1)*value.coerceIn(0f,1f), y + 18, p)
        text(c, r - 86, y + 18, label, 12f, color, false)
    }

    private fun title(c: Canvas, x: Float, y: Float, s: String) = text(c, x, y, s, 19f, yellow, true)

    private fun text(c: Canvas, x: Float, base: Float, s: String, size: Float, color: Int, center: Boolean) {
        p.style = Paint.Style.FILL; p.textSize = size; p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL); p.isAntiAlias = false; p.color = Color.argb(150,0,0,0)
        val tx = if (center) x - p.measureText(s)/2 else x
        c.drawText(s, tx + 2, base + 2, p); p.color = color; c.drawText(s, tx, base, p)
    }

    private fun textBlock(c: Canvas, x: Float, base: Float, s: String, size: Float, color: Int, maxX: Float) {
        p.textSize = size; var line = ""; var y = base
        for (word in s.split(" ")) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (p.measureText(candidate) > maxX-x && line.isNotEmpty()) { text(c,x,y,line,size,color,false); line=word; y += size+3 } else line=candidate
        }
        if (line.isNotEmpty()) text(c,x,y,line,size,color,false)
    }

    private fun measure(s: String, size: Float): Float { p.textSize=size; return p.measureText(s) }
    private fun state() = BodyStore.current(context)
    private fun food() = state().food.toInt()
    private fun energy() = state().energy.toInt()
    private fun pulse(): Int { val s=state(); val stress=(100-s.water)*.22f+(100-s.food)*.11f+(100-s.energy)*.25f; return (58+stress+5f*kotlin.math.sin(pulsePhase)).toInt().coerceIn(42,135) }
    private fun oxygen() = ((state().water*.25f+state().energy*.5f+40f)).toInt().coerceIn(55,100)
    private fun brainLoad() = (48f+(100-state().energy)*.35f+(100-state().water)*.12f).toInt().coerceIn(20,99)
    private fun breath() = (12f+(100-state().energy)*.025f+(100-state().water)*.012f).toInt().coerceIn(8,24)
    private fun muscle() = (state().energy*.55f+state().water*.35f+10f).toInt().coerceIn(0,100)

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX=e.x; downY=e.y; lastY=e.y; return true }
            MotionEvent.ACTION_MOVE -> { val dy=e.y-lastY; if(abs(e.y-downY)>18){ scroll=(scroll-dy).coerceIn(0f,maxScroll()); lastY=e.y; invalidate() }; return true }
            MotionEvent.ACTION_UP -> { val dx=e.x-downX; val dy=e.y-downY; if(abs(dx)>70&&abs(dx)>abs(dy)&&selected==null){ tab=if(dx<0)nextTab() else prevTab();scroll=0f;invalidate();return true }; handleTap(e.x,e.y); return true }
        }
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        val margin=max(18f,width*.035f); val top=max(34f,height*.055f); val l=margin+10f; val r=width-margin-10f
        if (selected != null) {
            if (y in (top+88f)..(top+128f)) { selected=null; invalidate(); return }
            if (y in (top+88f+405f)..(top+88f+455f)) { performSystemAction(selected!!, x, y, l, r, top); return }
            return
        }
        val tabTop=top+10f; val tabBottom=top+72f
        if (y in tabTop..tabBottom) { val gap=6f; val tw=(r-l-gap*3)/4f; val i=((x-l)/(tw+gap)).toInt(); if(i in 0..3){tab=Tab.values()[i];scroll=0f;invalidate();return} }
        if (y in (top-39f)..top && x>r-310f) { notifications=!notifications;context.getSharedPreferences("body_ui",0).edit().putBoolean("notifications",notifications).apply();invalidate();return }
        if(tab==Tab.SYSTEMS){ val start=top+88f+48f; val gap=7f; val rh=min(67f,(height-(top+88f+12f)-start-6*gap)/7f); val i=((y-start)/(rh+gap)).toInt(); if(i in 0..6){selected=SystemId.values()[i];scroll=0f;invalidate()} }
    }

    private fun performSystemAction(id:SystemId, x:Float, y:Float, l:Float, r:Float, top:Float) {
        val gap=12f; val aw=(r-l-36f-gap)/2f; val localX=x-l-18f; if(localX<0 || localX>2*aw+gap) return
        val action=(localX/(aw+gap)).toInt()
        when(id) {
            SystemId.STOMACH -> if(action==0) BodyStore.update(context,{it.copy(food=(it.food+BodyState.EAT).coerceAtMost(100f))},"Поедание завершено. Желудок получил работу.") else BodyStore.update(context,{it.copy(food=0f)},"Желудок очищен. Это было странное решение.")
            SystemId.ENERGY -> if(action==0) BodyStore.update(context,{it.copy(energy=(it.energy+BodyState.REST).coerceAtMost(100f))},"Отдых завершён. Энергия восстановилась.") else BodyStore.update(context,{it.copy(energy=(it.energy-30f).coerceAtLeast(0f))},"Энергия принудительно снижена.")
            SystemId.HEART -> if(action==0) BodyStore.addEvent(context,"Сердце успокоилось.") else BodyStore.addEvent(context,"Сердце получило нагрузку.","warning")
            else -> if(action==0) BodyStore.addEvent(context,"Система ${systemName(id)} стабилизирована.") else BodyStore.addEvent(context,"Система ${systemName(id)} подверглась имитации.")
        }
        invalidate()
    }

    private fun maxScroll() = when(tab){Tab.SYSTEMS->0f;Tab.NOW->180f;Tab.CASCADES->180f;Tab.JOURNAL->max(0f,BodyStore.events(context).size*61f-(height*.55f))}
    private fun nextTab()=Tab.values()[(tab.ordinal+1)%4]
    private fun prevTab()=Tab.values()[(tab.ordinal+3)%4]
}
