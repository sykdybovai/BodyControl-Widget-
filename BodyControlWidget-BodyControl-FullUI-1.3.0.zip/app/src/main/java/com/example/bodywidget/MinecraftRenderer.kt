package com.example.bodywidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.roundToInt

/** Pixel-art renderer for the standalone BodyControl-style home-screen widget. */
object MinecraftRenderer {
    const val W = 132
    const val PAD = 5
    const val BAR_H = 9
    const val BTN_H = 14
    const val BTN_W = 38
    const val BTN_GAP = 3
    const val BTN_MARGIN = (W - (3 * BTN_W + 2 * BTN_GAP)) / 2
    private const val BAR_W = 72

    private val BG = 0xF008090C.toInt()
    private val BORDER = 0xFF34383E.toInt()
    private val TRACK = 0xFF42464B.toInt()
    private val BTN_FILL = 0xFF676767.toInt()
    private val BTN_LIGHT = 0xFFB0B0B0.toInt()
    private val BTN_DARK = 0xFF343434.toInt()
    private val C_RED = 0xFFFF3F3F.toInt()
    private val C_GREEN = 0xFF50D96A.toInt()
    private val C_BLUE = 0xFF3D9BFF.toInt()
    private val C_CYAN = 0xFF25C9D4.toInt()
    private val C_YELLOW = 0xFFFFD52D.toInt()

    private val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        style = Paint.Style.FILL
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    private val HEART = listOf(".##.##.", "#######", "#######", ".#####.", "..###..", "...#...")
    private val DROP = listOf("...#...", "..###..", ".#####.", ".#####.", "..###..", "...#...")
    private val MEAT = listOf("...###.", "..####.", "..#####", "...###.", "..#....", ".#.....", "##.....")
    private val BOLT = listOf("....##.", "...##..", "..##...", ".#####.", "...##..", "..##...", ".##....")

    fun heightFor(aspect: Float): Int = (W * aspect).roundToInt().coerceIn(82, 110)
    fun buttonTop(h: Int): Int = h - PAD - BTN_H

    fun render(s: BodyState, h: Int, scale: Int): Bitmap {
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        rect(c, 0, 0, W, h, BG)
        rect(c, 1, 1, W - 2, 1, BORDER)
        rect(c, 1, h - 2, W - 2, 1, BORDER)
        rect(c, 1, 1, 1, h - 2, BORDER)
        rect(c, W - 2, 1, 1, h - 2, BORDER)

        // Header from the reference: red heart + "Жизни: 6".
        drawTinyHeart(c, PAD, 3, C_RED)
        text(c, PAD + 8, 3, "Жизни: 6", C_RED, 7f)

        val gap = (h - 18 - 2 * PAD - BTN_H - 4 * BAR_H) / 4
        var y = 17
        val pulse = s.pulse
        statRow(c, y, (pulse - 40).toFloat(), if (pulse > 100) C_RED else C_GREEN, HEART, C_RED, "$pulse BPM", C_RED)
        y += BAR_H + gap
        statRow(c, y, s.water, C_BLUE, DROP, C_BLUE, "${s.water.toInt()}%", C_BLUE)
        y += BAR_H + gap
        statRow(c, y, s.food, C_CYAN, MEAT, C_CYAN, "${s.food.toInt()}%", C_CYAN)
        y += BAR_H + gap
        statRow(c, y, s.energy, C_YELLOW, BOLT, C_YELLOW, "${s.energy.toInt()}%", C_YELLOW)

        val by = buttonTop(h)
        button(c, BTN_MARGIN, by, DROP, C_BLUE, "+${BodyState.DRINK.toInt()}")
        button(c, BTN_MARGIN + BTN_W + BTN_GAP, by, MEAT, C_CYAN, "+${BodyState.EAT.toInt()}")
        button(c, BTN_MARGIN + 2 * (BTN_W + BTN_GAP), by, BOLT, C_YELLOW, "+${BodyState.REST.toInt()}")

        bmp.setPixel(0, 0, 0); bmp.setPixel(W - 1, 0, 0)
        bmp.setPixel(0, h - 1, 0); bmp.setPixel(W - 1, h - 1, 0)
        return Bitmap.createScaledBitmap(bmp, W * scale, h * scale, false)
    }

    private fun statRow(c: Canvas, y: Int, value: Float, bar: Int, icon: List<String>, iconColor: Int, label: String, textColor: Int) {
        rect(c, PAD, y, BAR_W, BAR_H, Color.BLACK)
        rect(c, PAD + 1, y + 1, BAR_W - 2, BAR_H - 2, TRACK)
        val fw = ((BAR_W - 2) * value.coerceIn(0f, 100f) / 100f).toInt()
        if (fw > 0) {
            rect(c, PAD + 1, y + 1, fw, BAR_H - 2, bar)
            rect(c, PAD + 1, y + 1, fw, 1, shade(bar, 1.45f))
        }
        val ix = PAD + BAR_W + 3
        drawIcon(c, ix, y + 1, icon, iconColor)
        text(c, ix + 9, y + 1, label, textColor, 7f)
    }

    private fun button(c: Canvas, x: Int, y: Int, icon: List<String>, iconColor: Int, label: String) {
        rect(c, x, y, BTN_W, BTN_H, Color.BLACK)
        rect(c, x + 1, y + 1, BTN_W - 2, BTN_H - 2, BTN_FILL)
        rect(c, x + 1, y + 1, BTN_W - 2, 1, BTN_LIGHT)
        rect(c, x + 1, y + 1, 1, BTN_H - 2, BTN_LIGHT)
        rect(c, x + 1, y + BTN_H - 2, BTN_W - 2, 1, BTN_DARK)
        rect(c, x + BTN_W - 2, y + 1, 1, BTN_H - 2, BTN_DARK)
        drawIcon(c, x + 4, y + 3, icon, iconColor)
        text(c, x + 14, y + 3, label, Color.WHITE, 7f)
    }

    private fun drawTinyHeart(c: Canvas, x: Int, y: Int, color: Int) {
        val rows = listOf("#.#", "###", ".#.")
        rows.forEachIndexed { yy, row -> row.forEachIndexed { xx, ch -> if (ch == '#') rect(c, x + xx, y + yy, 1, 1, color) } }
    }

    private fun drawIcon(c: Canvas, x: Int, y: Int, rows: List<String>, main: Int) {
        rows.forEachIndexed { r, row ->
            row.forEachIndexed { col, v ->
                val color = when (v) { '#' -> main; else -> 0 }
                if (color != 0) rect(c, x + col, y + r, 1, 1, color)
            }
        }
    }

    private fun text(c: Canvas, x: Int, y: Int, s: String, color: Int, size: Float) {
        paint.textSize = size
        paint.color = shade(color, 0.25f)
        c.drawText(s, x + 1f, y + size + 1f, paint)
        paint.color = color
        c.drawText(s, x.toFloat(), y + size, paint)
    }

    private fun rect(c: Canvas, x: Int, y: Int, w: Int, h: Int, color: Int) {
        paint.color = color
        c.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), paint)
    }

    private fun shade(c: Int, f: Float): Int {
        fun ch(v: Int): Int = if (f <= 1f) (v * f).toInt() else (v + (255 - v) * (f - 1f)).toInt().coerceIn(0, 255)
        val r = ch((c shr 16) and 0xFF); val g = ch((c shr 8) and 0xFF); val b = ch(c and 0xFF)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }
}
